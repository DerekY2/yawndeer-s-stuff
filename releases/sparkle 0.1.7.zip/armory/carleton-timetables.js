```
data: [sem,year] --> [30=fall,20=summer,10=winter],2025
keys:
  carleton
  ottawa
  waterloo
```
chrome.storage.local.get(['carleton'],(results)=>{
  r=results['carleton']
  
})