msg='\nNavigate to "Detail Schedule"\n\nSparkling H2O2'
try{
  alert(msg)
}
catch(err){
  //console.log(err)
}