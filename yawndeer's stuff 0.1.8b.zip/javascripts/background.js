// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   if (message.action === 'startListener' && message.url && message.file) {
//     console.log('Received background request');
//     const iurl='https://central.carleton.ca/prod/bwskfshd.P_CrseSchd'
//     // Define a function to handle the onCompleted event
//     const handleNavigationCompleted = (details) => {
//       // Check if the URL matches your criteria
//       if (details.frameId === 0 && details.url.includes(iurl)) {
//         chrome.scripting.executeScript({
//           target: { tabId: details.tabId },
//           files: [message.file]
//         });
//         console.log('Injected script into tab:', details.tabId);
//       }
//     };

//     // Add the listener for the onCompleted event
//     chrome.webNavigation.onCompleted.addListener(handleNavigationCompleted);

//     // Optionally, you can remove the listener after a certain condition is met
//     // For example, after a certain number of injections or after a timeout
//     // Here, we remove the listener after 5 minutes (300000 milliseconds)
//     setTimeout(() => {
//       chrome.webNavigation.onCompleted.removeListener(handleNavigationCompleted);
//       console.log('Removed navigation completed listener after timeout');
//     }, 300000); // 5 minutes
//   }
// });

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   if (message.action === 'navigateLeft') {
//     chrome.tabs.query({ currentWindow: true }, (tabs) => {
//       chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
//         if (activeTabs.length > 0) {
//           const currentTab = activeTabs[0];
//           const currentIndex = currentTab.index;

//           // Find the index of the tab to the left
//           const leftTabIndex = currentIndex > 0 ? currentIndex - 1 : tabs.length - 1;

//           // Activate the tab to the left
//           chrome.tabs.update(tabs[leftTabIndex].id, { active: true });
//         }
//       });
//     });
//   } else if (message.action === 'alertRight' && message.message) {
//     chrome.tabs.query({ currentWindow: true }, (tabs) => {
//       chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
//         if (activeTabs.length > 0) {
//           const currentTab = activeTabs[0];
//           const currentIndex = currentTab.index;

//           // Find the index of the tab to the right
//           const rightTabIndex = (currentIndex + 1) % tabs.length;

//           // Activate the tab to the right
//           chrome.tabs.update(tabs[rightTabIndex].id, { active: true }, () => {
//             // Inject a script to show an alert in the right tab
//             chrome.scripting.executeScript({
//               target: { tabId: tabs[rightTabIndex].id },
//               func: (msg) => alert(msg),
//               args: [message.message]
//             });
//           });
//         }
//       });
//     });
//   }
// });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received:', message);

  if (message.action === 'closeTab' && sender.tab) {
    chrome.tabs.remove(sender.tab.id, () => {
      console.log('Tab closed:', sender.tab.id);
    });
  } else if (message.action === 'closeRightTab' && sender.tab) {
    chrome.tabs.query({ currentWindow: true }, (tabs) => {
      const currentTabIndex = sender.tab.index;
      const rightTabIndex = (currentTabIndex + 1) % tabs.length;

      if (tabs[rightTabIndex]) {
        chrome.tabs.remove(tabs[rightTabIndex].id, () => {
          console.log('Closed tab to the right:', tabs[rightTabIndex].id);
        });
      } else {
        console.log('No tab to the right found.');
      }
    });
  } else if (message.action === 'closeLeftTab' && sender.tab) {
    chrome.tabs.query({ currentWindow: true }, (tabs) => {
      const currentTabIndex = sender.tab.index;
      const leftTabIndex = currentTabIndex > 0 ? currentTabIndex - 1 : -1;

      if (leftTabIndex >= 0 && tabs[leftTabIndex].url === 'https://central.carleton.ca/prod/bwskfshd.P_CrseSchd') {
        chrome.tabs.remove(tabs[leftTabIndex].id, () => {
          console.log('Closed tab to the left with the specified URL:', tabs[leftTabIndex].id);
        });
      } else {
        console.log('No tab to the left with the specified URL found.');
      }
    });
  }
});
